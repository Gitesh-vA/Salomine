export const environment = {
  production: true,
  APIUrl:"https://www.salotime.com/gradabenshe",

  login: true,
};

