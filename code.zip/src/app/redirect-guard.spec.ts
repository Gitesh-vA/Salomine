import { RedirectGuard } from './redirect-guard';

describe('RedirectGuard', () => {
  it('should create an instance', () => {
    expect(new RedirectGuard()).toBeTruthy();
  });
});
