
import { Injectable } from '@angular/core';
import { Category } from '../../models/Home/category';
import * as moment from 'moment';
import { NgxImageCompressService } from 'ngx-image-compress';
import { HttpResponseBase } from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
  providedIn: 'root'
})
export class WeekDays {

public weekday = new Array(7);

/*this.wekday[0] = "Sun"; 
this.wekday[1] = "Mon"; 
this.weekday[2] = "Tue"; 
weekday[3] = "Wed"; 
weekday[4] = "Thu"; 
weekday[5] = "Fri"; 
weekday[6] = "Sat"; */

}
