import { MyHammerConfig } from './my-hammer-config';

describe('MyHammerConfig', () => {
  it('should create an instance', () => {
    expect(new MyHammerConfig()).toBeTruthy();
  });
});
