"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AvailableTime = /** @class */ (function () {
    function AvailableTime() {
    }
    return AvailableTime;
}());
exports.AvailableTime = AvailableTime;
//# sourceMappingURL=available-time.js.map