"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Settings = /** @class */ (function () {
    function Settings() {
    }
    return Settings;
}());
exports.Settings = Settings;
//# sourceMappingURL=settings.js.map