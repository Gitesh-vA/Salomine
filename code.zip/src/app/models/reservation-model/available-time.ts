export class AvailableTime {
    time: string;
    available: boolean;
    message: string;
    displayTime: string;
}


