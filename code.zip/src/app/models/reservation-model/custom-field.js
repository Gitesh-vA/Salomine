"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CustomField = /** @class */ (function () {
    function CustomField() {
    }
    return CustomField;
}());
exports.CustomField = CustomField;
//# sourceMappingURL=custom-field.js.map