"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AvailableDate = /** @class */ (function () {
    function AvailableDate() {
    }
    return AvailableDate;
}());
exports.AvailableDate = AvailableDate;
//# sourceMappingURL=available-date.js.map