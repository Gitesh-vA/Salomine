export class dayOff {
    date: string;
    isSelected: boolean;
    isAlreadyDayOff: Boolean;
}
