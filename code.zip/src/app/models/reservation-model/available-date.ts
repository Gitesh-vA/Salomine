export class AvailableDate {
    date: string;
    available: boolean;
    message: string;
    openT: string;
    closeT: string;
    restTF:string;
    restTA:string;
}
