export class CustomField {
    Name: string;
    Type: string;
    Required: boolean; 
    Error: string;
    Id: number;
}
