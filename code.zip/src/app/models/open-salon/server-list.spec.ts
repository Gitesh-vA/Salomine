import { ServerList } from './server-list';

describe('ServerList', () => {
  it('should create an instance', () => {
    expect(new ServerList()).toBeTruthy();
  });
});
