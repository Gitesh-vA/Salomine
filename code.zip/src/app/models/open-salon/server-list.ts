export class ServerList {
    id:number;
    value:string;


       //todo: contructor for test should to remove it 
       constructor(private _id: number,private _value : string) {

        this.id =  _id;
        this.value = _value;
  
     }
    }
