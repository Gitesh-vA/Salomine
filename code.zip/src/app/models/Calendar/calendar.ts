export class CalendarModel {
    salonID: string = null;
    UserID: String = null;
    Name:String = null;
    year:number = -1;
    month:Number = -1;
    day: Number = -1;
    fromHour:Number = -1;
    fromMin:Number = -1;
    atHour:Number = -1;
    atMin:Number = -1;
    servercies:String = null;
}
